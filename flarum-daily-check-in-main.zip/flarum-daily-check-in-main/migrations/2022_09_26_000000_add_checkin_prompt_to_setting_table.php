<?php

use Flarum\Database\Migration;

return Migration::addSettings([
    'ziven-forum-checkin.checkinSuccessPromptType' => 0,
    'ziven-forum-checkin.checkinSuccessPromptText' => "",
    'ziven-forum-checkin.checkinSuccessPromptRewardText' => ""
]);
