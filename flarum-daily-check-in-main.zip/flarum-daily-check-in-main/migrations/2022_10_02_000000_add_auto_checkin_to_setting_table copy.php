<?php

use Flarum\Database\Migration;

return Migration::addSettings([
    'ziven-forum-checkin.autoCheckIn' => 0,
    'ziven-forum-checkin.autoCheckInDelay' => 0
]);
